var fs = require('fs')

module.exports = {createManifesto, createMetadata}
/*
var obj1 = [
    {
        fieldname: 'myFile',
        originalname: 'Mongo tutorial.zip',
        encoding: '7bit',
        mimetype: 'application/x-zip-compressed',
        destination: 'uploads/',
        filename: '62c1741dd756dc686150b888796ecd18',
        path: 'uploads\62c1741dd756dc686150b888796ecd18',
        size: 2054916
      },
      {
        fieldname: 'OI',
        originalname: 'mine.pdf',
        encoding: '7bit',
        mimetype: 'application/x-zip-compressed',
        destination: 'uploads/',
        filename: '62c1741dd756dc686150b888796ecd18',
        path: 'uploads\62c1741dd756dc686150b888796ecd18',
        size: 2054916
      },
      {
        fieldname: 'aa',
        originalname: 'MINe.pdf',
        encoding: '7bit',
        mimetype: 'application/x-zip-compressed',
        destination: 'uploads/',
        filename: '62c1741dd756dc686150b888796ecd18',
        path: 'uploads\62c1741dd756dc686150b888796ecd18',
        size: 2054916
      }
]
*/

function createManifesto(obj){
    var fileNames = []

    obj.forEach(f => {
        fileNames.push(f.originalname)
    })

    fs.appendFileSync('manifesto.json', '[', function(err){
        if (err) console.log(err)
    })

    fileNames.forEach(f => {
        if(fileNames[fileNames.length - 1] == f){
            var file = '{"file":' +  '"' + f + '"' + '}]'
            fs.appendFileSync('manifesto.json', file , function(err){
            if (err) console.log(err)
            })
        }
        else{
            var file = '{"file":' +  '"' + f + '"' + '},'
            fs.appendFileSync('manifesto.json', file , function(err){
            if (err) console.log(err)
            })
        } 
    })

}

function createMetadata(obj){
    obj.forEach(f => {
        var meta = 'fieldname:' + f.fieldname + '\n' + 'encoding:' + f.encoding + '\n' + 'mimetype:' + f.mimetype + '\n' +  'file:' + f.size + '\n\n'
        fs.appendFileSync('metadata.txt', meta, function(err){
            if (err) console.log(err)
        })
    })
}

//createManifesto(obj1)
//createMetadata(obj1)
