public class Utilizador {

	private Biblioteca biblioteca;
	private string nome;
	private string email;
	private string password;

}