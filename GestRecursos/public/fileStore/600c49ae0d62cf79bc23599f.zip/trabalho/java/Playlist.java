public class Playlist {

	private Media musicas;
	private String nome;

}