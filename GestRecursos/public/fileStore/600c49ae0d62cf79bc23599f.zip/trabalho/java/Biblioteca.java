public class Biblioteca {

	private Media musicas;
	private Playlist playlists;

}