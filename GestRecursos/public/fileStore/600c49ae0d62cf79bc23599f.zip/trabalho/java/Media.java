public class Media {

	private double duracao;
	private string categoria;
	private string artista;
	private string nome;

}