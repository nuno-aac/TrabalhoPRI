public class MediaCenter {

	private Utilizador utilizadores;
	private Biblioteca bibliotecaGeral;
	private Utilizador admin;
	private Utilizador currentUser;

}